package com.spring.day7.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.day7.command.*;
import com.spring.day7.util.Constant;

@Controller
public class BController {
	BCommand command=null;
	private JdbcTemplate template;
	
	@RequestMapping("/list")
	public String list(HttpServletRequest request, Model model) {
		if(request.getSession().getAttribute("id")==null) {
			return "redirect:member/loginForm";
		}
		System.out.println("list()");
		command = new BListCommand();
		command.execute(model);
		return "list";
	}
	@Autowired
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
		Constant.template = this.template;
	}
	@RequestMapping("/write_view")
	public String write_view(Model model) {
		System.out.println("write_view()");
		return "write_view";
	}
	@RequestMapping("/write")
	public String write(HttpServletRequest request,Model model) {
		System.out.println("write()");
		
		model.addAttribute("request",request);
		command = new BWriteCommand();
		command.execute(model);
		return "redirect:list";
	}
	@RequestMapping("/content_view")    //
	   public String content_view(HttpServletRequest request, Model model) {
	      
	      System.out.println("content_view()");
	      
	      model.addAttribute("request", request);
	      command = new BContentCommand();
	      command.execute(model);
	      
	      return "content_view";
	   }
	@RequestMapping(value="/modify",method=RequestMethod.POST)
	public String modify(HttpServletRequest request,Model model) {
		System.out.println("modify()");
		
		model.addAttribute("request",request);
		command = new BModifyCommand();
		command.execute(model);
		return "redirect:list";
	}
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request,Model model) {
		System.out.println("delete()");
		
		model.addAttribute("request",request);
		command = new BDeleteCommand();
		command.execute(model);
		return "redirect:list";
	}
	@RequestMapping("/reply_view")    //
	   public String reply_view(HttpServletRequest request, Model model) {
	      
	      System.out.println("reply_view()");
	      
	      model.addAttribute("request", request);
	      command = new BReplyViewCommand();
	      command.execute(model);
	      
	      return "reply_view";
	   }
	@RequestMapping("/reply")
	public String reply(HttpServletRequest request,Model model) {
		System.out.println("reply()");
		
		model.addAttribute("request",request);
		command = new BReplyCommand();
		command.execute(model);
		return "redirect:list";
	}
}
