package com.spring.day7.mCommand;

import org.springframework.ui.Model;

public interface MCommand {
	void execute(Model model);
}
