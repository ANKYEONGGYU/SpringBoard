package com.spring.day7.mCommand;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.spring.day7.mDao.MDao;
import com.spring.day7.mDto.MDto;

public class MInfoCommand implements MCommand{
	@Override
	public void execute(Model model) {
		Map<String, Object>map = model.asMap();
		HttpServletRequest request = (HttpServletRequest)map.get("request");
		
		String id = request.getParameter("id");
		
		MDao dao = new MDao();
		MDto dto = dao.getMemInfo(id);
		model.addAttribute("info",dto);
	}
}
