package com.spring.day7.mCommand;

import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.Model;

import com.spring.day7.mDao.MDao;
import com.spring.day7.mDto.MDto;

public class MListCommand implements MCommand{
	@Override
	public void execute(Model model) {
		MDao dao = new MDao();
		ArrayList<MDto> list = dao.getList();
		model.addAttribute("list",list);
	}
}
