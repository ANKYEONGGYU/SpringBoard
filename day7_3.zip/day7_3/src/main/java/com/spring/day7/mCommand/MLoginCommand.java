package com.spring.day7.mCommand;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.spring.day7.mDao.MDao;

public class MLoginCommand implements MCommand{
	private boolean result;
	public boolean isResult() {
		return result;
	}
	@Override
	public void execute(Model model) {
		Map<String,Object>map = model.asMap();
		HttpServletRequest request = (HttpServletRequest)map.get("request");
		
		String id = request.getParameter("userId");
		String pw = request.getParameter("userPw");
		
		MDao dao = new MDao();
		result = dao.login(id,pw);
		if (result==true)request.getSession().setAttribute("id", id);
	}
}
