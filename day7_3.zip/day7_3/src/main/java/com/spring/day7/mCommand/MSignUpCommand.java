package com.spring.day7.mCommand;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.spring.day7.mDao.MDao;

public class MSignUpCommand implements MCommand{
	@Override
	public void execute(Model model) {
		Map<String, Object> map = model.asMap();
		HttpServletRequest request = (HttpServletRequest)map.get("request");
		
		String id = request.getParameter("my_id");
		String pw = request.getParameter("my_pwd");
		String name = request.getParameter("my_name");
		String email = request.getParameter("my_mail");
		String ident = request.getParameter("identi1")+"-"
				+ request.getParameter("identi2");
		
		String birthStr = request.getParameter("my_year")+"."+request.getParameter("my_month")+"."+ request.getParameter("my_day");
		DateFormat formatter = new SimpleDateFormat("yyyy.MM.dd");
		Date birthUtil = new Date();
		try {
			birthUtil = formatter.parse(birthStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}

        long timeInMilliSeconds = birthUtil.getTime();
        java.sql.Date birth = new java.sql.Date(timeInMilliSeconds);
        
        String interests[] = request.getParameterValues("interest");
		String interest = "";
		if(interests!=null){
			for (int i=0; i<interests.length;i++){
				interest += interests[i];
				if(i!=interests.length-1)interest += ", ";
			}
		}
		String postCode = request.getParameter("address");
		String address = request.getParameter("address1") + " "
				+ request.getParameter("address2")+" "+request.getParameter("address3");
		String info = request.getParameter("my_intro");
		
		MDao dao = new MDao();
		dao.signup(id,pw,name,email,ident,birth,postCode,info,address,interest);
	}
}
