package com.spring.day7.mController;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.day7.mCommand.*;
import com.spring.day7.util.Constant;

@Controller
public class MController {
	MCommand command;
	private JdbcTemplate template;
	@Autowired
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
		Constant.template = this.template;
	}
	@RequestMapping("/member/signupForm")
	public String signup_form(Model model) {
		System.out.println("signup_Form()");
		return "user/signupForm";
	}
	@RequestMapping("/member/signup")
	public String signup(HttpServletRequest request, Model model) {
		System.out.println("signup_Form()");
		model.addAttribute("request",request);
		command = new MSignUpCommand();
		command.execute(model);
		return "redirect:loginForm";
	}
	@RequestMapping("/member/loginForm")
	public String login_form(Model model) {
		System.out.println("login_Form()");
		return "user/loginForm";
	}
	@RequestMapping("/member/login")
	public String login(HttpServletRequest request, Model model) {
		System.out.println("login()");
		model.addAttribute("request",request);
		command = new MLoginCommand();
		command.execute(model);
		return "redirect:../list";
	}
	@RequestMapping("/member/mList")
	public String mList(Model model) {
		System.out.println("mList()");
		command = new MListCommand();
		command.execute(model);
		return "user/member_list";
	}
	@RequestMapping("/member/info")
	public String info(HttpServletRequest request, Model model) {
		System.out.println("info()");
		model.addAttribute("request",request);
		command = new MInfoCommand();
		command.execute(model);
		return "user/member_info";
	}
	@RequestMapping("/member/del")
	public String del(HttpServletRequest request, Model model) {
		System.out.println("del()");
		model.addAttribute("request",request);
		command = new MDeleteCommand();
		command.execute(model);
		return "redirect:mList";
	}
	@RequestMapping("/member/logout")
	public String logout(HttpServletRequest request,Model model) {
		System.out.println("logout()");
		model.addAttribute("request",request);
		command = new MLogoutCommand();
		command.execute(model);
		return "redirect:loginForm";
	}
}
