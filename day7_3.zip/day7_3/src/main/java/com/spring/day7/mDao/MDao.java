package com.spring.day7.mDao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;

import com.spring.day7.mDto.MDto;
import com.spring.day7.util.Constant;

public class MDao {
	JdbcTemplate template;
	
	public MDao() {
		this.template = Constant.template;
	}

	public void signup(final String id, final String pw, final String name, 
			final String email, final String ident, final Date birth, final String postCode,
			final String info, final String address, final String interest) {
		this.template.update(new PreparedStatementCreator(){

			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				String query = "insert into mvc_member values(?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement pstmt = con.prepareStatement(query);
				pstmt.setString(1, id);
				pstmt.setString(2, pw);
				pstmt.setString(3, name);
				pstmt.setString(4, email);
				pstmt.setString(5, ident);
				pstmt.setDate(6, birth);
				pstmt.setString(7, postCode);
				pstmt.setString(8, info);
				pstmt.setString(9, address);
				pstmt.setString(10, interest);
				return pstmt;
			}
			
		});
	}

	public boolean login(final String id, final String pw) {
		MDto dto = getMemInfo(id);
		if (dto!=null) {
			if (dto.getPw().equals(pw)) {
				return true;
			}
		}
		return false;
	}

	public MDto getMemInfo(String id) {
		String query = "select * from mvc_member where Id='"+id+"'";
		return template.queryForObject(query, new BeanPropertyRowMapper<MDto>(MDto.class));
	}

	public ArrayList<MDto> getList() {
		String query = "select * from mvc_member";
		return (ArrayList<MDto>)template.query(query, new BeanPropertyRowMapper<MDto>(MDto.class));
	}

	public void deleteMem(final String id) {
		String query = "delete from mvc_member where id = ?";
		this.template.update(query,new PreparedStatementSetter(){
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1,id);
			}
		});
	}

}
